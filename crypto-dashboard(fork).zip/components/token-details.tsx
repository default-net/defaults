import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink } from "lucide-react"
import { TokenLogo } from "@/components/token-logo"

interface TokenDetailsProps {
  name: string
  symbol: string
  contractAddress: string
  maxTotalSupply: string
  circulatingSupply: string
  fullyDilutedMarketCap: string
  circulatingMarketCap: string
  price: string
  btcPrice?: string
  priceChange?: string
  totalValueLocked: string
  network: string
  explorerUrl: string
  apy: string
  state: string
  startDate: string
  endDate?: string
}

export function TokenDetails({
  name,
  symbol,
  contractAddress,
  maxTotalSupply,
  circulatingSupply,
  fullyDilutedMarketCap,
  circulatingMarketCap,
  price,
  btcPrice,
  priceChange,
  totalValueLocked,
  network,
  explorerUrl,
  apy,
  state,
  startDate,
  endDate,
}: TokenDetailsProps) {
  return (
    <Card className="bg-background/50 backdrop-blur">
      <CardHeader>
        <div className="flex items-center gap-4 mb-2">
          <TokenLogo symbol={symbol} className="w-12 h-12" />
          <CardTitle className="flex items-center justify-between flex-1">
            <div>
              <span>
                {name} ({symbol})
              </span>
              {btcPrice && (
                <div className="text-sm font-normal text-muted-foreground mt-1">
                  {price} @ {btcPrice}
                  {priceChange && <span className="text-green-500 ml-1">({priceChange})</span>}
                </div>
              )}
            </div>
            <Badge variant="outline">{network}</Badge>
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent className="grid gap-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground">Contract Address</p>
            <p className="text-sm font-mono">{contractAddress}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Price</p>
            <p className="text-lg font-bold">{price}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground">Max Total Supply</p>
            <p>{maxTotalSupply}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Circulating Supply</p>
            <p>{circulatingSupply}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground">Fully Diluted Market Cap</p>
            <p>{fullyDilutedMarketCap}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Circulating Market Cap</p>
            <p>{circulatingMarketCap}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground">Total Value Locked</p>
            <p>{totalValueLocked}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">APY</p>
            <p>{apy}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground">State</p>
            <p>{state}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">{endDate ? "Date Range" : "Start Date"}</p>
            <p>{endDate ? `${startDate} - ${endDate}` : startDate}</p>
          </div>
        </div>
        <a
          href={explorerUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center text-sm text-primary hover:underline"
        >
          View on Explorer
          <ExternalLink className="ml-1 h-4 w-4" />
        </a>
      </CardContent>
    </Card>
  )
}

