import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { MetricsCard } from "@/components/metrics-card"
import { StatsChart } from "@/components/stats-chart"
import { VaultTable } from "@/components/vault-table"
import { BarChart3, ChevronDown, Globe, Home, LayoutDashboard, LifeBuoy, Settings, Wallet } from "lucide-react"
import { TokenDetails } from "@/components/token-details"

export default function Page() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="grid lg:grid-cols-[280px_1fr]">
        <aside className="border-r bg-background/50 backdrop-blur">
          <div className="flex h-16 items-center gap-2 border-b px-6">
            <Wallet className="h-6 w-6" />
            <span className="font-bold">Vaultify</span>
          </div>
          <div className="px-4 py-4">
            <Input placeholder="Search" className="bg-background/50" />
          </div>
          <nav className="space-y-2 px-2">
            <Button variant="ghost" className="w-full justify-start gap-2">
              <LayoutDashboard className="h-4 w-4" />
              Dashboard
            </Button>
            <Button variant="ghost" className="w-full justify-start gap-2">
              <BarChart3 className="h-4 w-4" />
              Statistics & Income
            </Button>
            <Button variant="ghost" className="w-full justify-start gap-2">
              <Globe className="h-4 w-4" />
              Market
            </Button>
            <Button variant="ghost" className="w-full justify-start gap-2">
              <Home className="h-4 w-4" />
              Funding
            </Button>
            <Button variant="ghost" className="w-full justify-start gap-2">
              <Wallet className="h-4 w-4" />
              Yield Vaults
              <ChevronDown className="ml-auto h-4 w-4" />
            </Button>
            <Button variant="ghost" className="w-full justify-start gap-2">
              <LifeBuoy className="h-4 w-4" />
              Support
            </Button>
            <Button variant="ghost" className="w-full justify-start gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </Button>
          </nav>
        </aside>
        <main className="p-6">
          <div className="mb-6 flex items-center justify-between">
            <div className="space-y-1">
              <h1 className="text-2xl font-bold">Overview</h1>
              <div className="text-sm text-muted-foreground">Aug 13, 2023 - Aug 18, 2023</div>
            </div>
            <Button variant="outline" className="gap-2">
              Ethereum Network
              <ChevronDown className="h-4 w-4" />
            </Button>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            <MetricsCard
              title="Your Balance"
              value="$74,892"
              change={{ value: "$1,340", percentage: "-2.1%", isPositive: false }}
            />
            <MetricsCard
              title="Your Deposits"
              value="$54,892"
              change={{ value: "$1,340", percentage: "+13.2%", isPositive: true }}
            />
            <MetricsCard
              title="Accrued Yield"
              value="$20,892"
              change={{ value: "$1,340", percentage: "+1.2%", isPositive: true }}
            />
          </div>
          <Card className="mt-6 p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-semibold">General Statistics</h2>
              <div className="flex gap-2">
                <Button size="sm" variant="ghost">
                  Today
                </Button>
                <Button size="sm" variant="ghost">
                  Last week
                </Button>
                <Button size="sm" variant="ghost">
                  Last month
                </Button>
                <Button size="sm" variant="ghost">
                  Last 6 month
                </Button>
                <Button size="sm" variant="ghost">
                  Year
                </Button>
              </div>
            </div>
            <StatsChart />
          </Card>
          <div className="mt-6">
            <VaultTable />
          </div>
          <div className="mt-6 space-y-6">
            <div>
              <h2 className="text-lg font-semibold mb-4">MATIC Token Details</h2>
              <TokenDetails
                name="MATIC"
                symbol="MATIC"
                contractAddress="0x299cd046bfed4003544040fdc20776a73055f743"
                maxTotalSupply="100,000,000,000,000"
                circulatingSupply="4,200,000,000,000,000"
                fullyDilutedMarketCap="$4,200,000,000,000,000"
                circulatingMarketCap="$4,200,000,000,000,000"
                price="$0.42"
                btcPrice="0.000004 BTC"
                priceChange="+2.57%"
                totalValueLocked="$1,234,567,890"
                network="Polygon Mainnet"
                explorerUrl="https://polygonscan.com/token/0x299cd046bfed4003544040fdc20776a73055f743"
                apy="8.56%"
                state="Flexible"
                startDate="05.31.2020"
                endDate="01.01.2025"
              />
            </div>
            <div>
              <h2 className="text-lg font-semibold mb-4">wSNS Token Details</h2>
              <TokenDetails
                name="wSNS"
                symbol="WSNS"
                contractAddress="0x25a2db8659707766b3452ab38bCeA593C7E6B559"
                maxTotalSupply="100,000,000,010,000"
                circulatingSupply="100,000,000,010,000"
                fullyDilutedMarketCap="$1,000,000,000,000"
                circulatingMarketCap="$100,000,000,010,000"
                price="$1.00"
                totalValueLocked="$6,700,000,000"
                network="Polygon Mainnet"
                explorerUrl="https://www.oklink.com/polygon/token/0x25a2db8659707766b3452ab38bCeA593C7E6B559"
                apy="8.56%"
                state="Fixed"
                startDate="02.10.2024"
              />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}

