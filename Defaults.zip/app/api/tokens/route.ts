import { NextResponse } from "next/server"

// Mock data - in production this would connect to your database
const mockTokensData = [
  {
    id: 1,
    symbol: "BTC",
    name: "Bitcoin",
    price: 45000.0 + (Math.random() - 0.5) * 1000,
    change24h: 2.5 + (Math.random() - 0.5) * 2,
    marketCap: 880000000000,
    volume24h: 25000000000,
    logo: "/bitcoin-logo.png",
    isFiat: false,
    chainId: 1,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 2,
    symbol: "ETH",
    name: "Ethereum",
    price: 3200.0 + (Math.random() - 0.5) * 200,
    change24h: 1.8 + (Math.random() - 0.5) * 2,
    marketCap: 385000000000,
    volume24h: 15000000000,
    logo: "/ethereum-logo.png",
    isFiat: false,
    chainId: 1,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 3,
    symbol: "POL",
    name: "Polygon",
    price: 1.0001 + (Math.random() - 0.5) * 0.1,
    change24h: -0.01 + (Math.random() - 0.5) * 1,
    marketCap: 134000000000,
    volume24h: 847200000,
    logo: "/tokens/logo.png",
    isFiat: false,
    chainId: 137,
    lastUpdated: new Date().toISOString(),
  },
  {
    id: 4,
    symbol: "USDT",
    name: "Tether USD",
    price: 1.0 + (Math.random() - 0.5) * 0.01,
    change24h: 0.01 + (Math.random() - 0.5) * 0.1,
    marketCap: 95000000000,
    volume24h: 45000000000,
    logo: "/tether-usdt-logo.png",
    isFiat: false,
    chainId: 1,
    lastUpdated: new Date().toISOString(),
  },
]

export async function GET() {
  try {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 100))

    return NextResponse.json({
      success: true,
      data: mockTokensData,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch tokens" }, { status: 500 })
  }
}
