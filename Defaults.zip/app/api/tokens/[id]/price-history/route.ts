import { NextResponse } from "next/server"

// Generate mock historical price data
function generatePriceHistory(basePrice: number, days = 30) {
  const history = []
  const now = new Date()

  for (let i = days; i >= 0; i--) {
    const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000)
    const variation = (Math.random() - 0.5) * 0.1 // ±10% variation
    const price = basePrice * (1 + variation)

    history.push({
      timestamp: date.toISOString(),
      price: price,
      volume: Math.random() * 1000000000,
    })
  }

  return history
}

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const { searchParams } = new URL(request.url)
    const period = searchParams.get("period") || "30d"

    // Mock base prices for different tokens
    const basePrices: { [key: string]: number } = {
      "1": 45000, // BTC
      "2": 3200, // ETH
      "3": 1.0001, // POL
      "4": 1.0, // USDT
    }

    const basePrice = basePrices[params.id] || 100
    const days = period === "7d" ? 7 : period === "30d" ? 30 : 365

    const priceHistory = generatePriceHistory(basePrice, days)

    return NextResponse.json({
      success: true,
      data: priceHistory,
      period,
      tokenId: params.id,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch price history" }, { status: 500 })
  }
}
