"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, RefreshCw, Bell } from "lucide-react"
import { PriceChart } from "@/components/price-chart"

interface Token {
  id: number
  symbol: string
  name: string
  price: number
  change24h: number
  marketCap: number
  volume24h: number
  logo: string
  lastUpdated: string
}

interface PriceTrackerProps {
  tokenId?: number
}

export function PriceTracker({ tokenId }: PriceTrackerProps) {
  const [tokens, setTokens] = useState<Token[]>([])
  const [loading, setLoading] = useState(true)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())
  const [autoRefresh, setAutoRefresh] = useState(true)

  const fetchTokens = async () => {
    try {
      const response = await fetch("/api/tokens")
      const result = await response.json()

      if (result.success) {
        setTokens(result.data)
        setLastUpdate(new Date())
      }
    } catch (error) {
      console.error("[v0] Failed to fetch token prices:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchTokens()
  }, [])

  useEffect(() => {
    if (!autoRefresh) return

    const interval = setInterval(() => {
      fetchTokens()
    }, 30000) // Update every 30 seconds

    return () => clearInterval(interval)
  }, [autoRefresh])

  const handleRefresh = () => {
    setLoading(true)
    fetchTokens()
  }

  const toggleAutoRefresh = () => {
    setAutoRefresh(!autoRefresh)
  }

  if (loading && tokens.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-32">
            <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        </CardContent>
      </Card>
    )
  }

  const displayTokens = tokenId ? tokens.filter((t) => t.id === tokenId) : tokens.slice(0, 4)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-serif font-bold">Live Price Tracking</h2>
          <p className="text-sm text-muted-foreground">Last updated: {lastUpdate.toLocaleTimeString()}</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={autoRefresh ? "default" : "secondary"} className="cursor-pointer" onClick={toggleAutoRefresh}>
            {autoRefresh ? "Auto-refresh ON" : "Auto-refresh OFF"}
          </Badge>
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {displayTokens.map((token) => (
          <Card key={token.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <img src={token.logo || "/placeholder.svg"} alt={token.name} className="w-6 h-6 rounded-full" />
                  {token.symbol}
                </CardTitle>
                <Button variant="ghost" size="sm">
                  <Bell className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-3xl font-bold font-mono">
                  $
                  {token.price.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: token.price < 1 ? 6 : 2,
                  })}
                </div>
                <div
                  className={`flex items-center gap-1 text-sm ${
                    token.change24h > 0
                      ? "text-chart-1"
                      : token.change24h < 0
                        ? "text-destructive"
                        : "text-muted-foreground"
                  }`}
                >
                  {token.change24h > 0 ? (
                    <TrendingUp className="h-3 w-3" />
                  ) : token.change24h < 0 ? (
                    <TrendingDown className="h-3 w-3" />
                  ) : null}
                  {token.change24h > 0 ? "+" : ""}
                  {token.change24h.toFixed(2)}% (24h)
                </div>
              </div>

              <div className="h-32">
                <PriceChart tokenId={token.id} />
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Market Cap</div>
                  <div className="font-medium">${(token.marketCap / 1e9).toFixed(2)}B</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Volume (24h)</div>
                  <div className="font-medium">${(token.volume24h / 1e9).toFixed(2)}B</div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
