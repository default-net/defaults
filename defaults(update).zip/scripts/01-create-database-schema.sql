-- Creating comprehensive database schema for token listing platform

-- Tokens table for storing cryptocurrency and fiat currency information
CREATE TABLE IF NOT EXISTS tokens (
  id SERIAL PRIMARY KEY,
  symbol VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  contract_address VARCHAR(100),
  chain_id INTEGER,
  decimals INTEGER DEFAULT 18,
  logo_url TEXT,
  website_url TEXT,
  whitepaper_url TEXT,
  is_fiat BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Price data table for real-time and historical prices
CREATE TABLE IF NOT EXISTS token_prices (
  id SERIAL PRIMARY KEY,
  token_id INTEGER REFERENCES tokens(id) ON DELETE CASCADE,
  price DECIMAL(20, 8) NOT NULL,
  market_cap BIGINT,
  volume_24h BIGINT,
  change_24h DECIMAL(10, 4),
  change_7d DECIMAL(10, 4),
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(token_id, timestamp)
);

-- Trading pairs for exchange functionality
CREATE TABLE IF NOT EXISTS trading_pairs (
  id SERIAL PRIMARY KEY,
  base_token_id INTEGER REFERENCES tokens(id) ON DELETE CASCADE,
  quote_token_id INTEGER REFERENCES tokens(id) ON DELETE CASCADE,
  exchange_rate DECIMAL(20, 8),
  liquidity BIGINT DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(base_token_id, quote_token_id)
);

-- Bridge transactions for cross-chain functionality
CREATE TABLE IF NOT EXISTS bridge_transactions (
  id SERIAL PRIMARY KEY,
  from_token_id INTEGER REFERENCES tokens(id),
  to_token_id INTEGER REFERENCES tokens(id),
  from_chain_id INTEGER NOT NULL,
  to_chain_id INTEGER NOT NULL,
  from_address VARCHAR(100) NOT NULL,
  to_address VARCHAR(100) NOT NULL,
  amount DECIMAL(20, 8) NOT NULL,
  fee DECIMAL(20, 8) DEFAULT 0,
  status VARCHAR(20) DEFAULT 'pending',
  tx_hash VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP
);

-- User documents for token verification
CREATE TABLE IF NOT EXISTS token_documents (
  id SERIAL PRIMARY KEY,
  token_id INTEGER REFERENCES tokens(id) ON DELETE CASCADE,
  document_type VARCHAR(50) NOT NULL,
  document_url TEXT NOT NULL,
  file_name VARCHAR(255),
  file_size INTEGER,
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_tokens_symbol ON tokens(symbol);
CREATE INDEX IF NOT EXISTS idx_tokens_contract_address ON tokens(contract_address);
CREATE INDEX IF NOT EXISTS idx_token_prices_token_timestamp ON token_prices(token_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_trading_pairs_tokens ON trading_pairs(base_token_id, quote_token_id);
CREATE INDEX IF NOT EXISTS idx_bridge_transactions_status ON bridge_transactions(status);
