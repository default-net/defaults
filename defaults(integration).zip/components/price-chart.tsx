"use client"

import { useState, useEffect } from "react"
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts"
import { Button } from "@/components/ui/button"

interface PriceData {
  timestamp: string
  price: number
  volume: number
}

interface PriceChartProps {
  tokenId: number
}

export function PriceChart({ tokenId }: PriceChartProps) {
  const [data, setData] = useState<PriceData[]>([])
  const [period, setPeriod] = useState("7d")
  const [loading, setLoading] = useState(true)

  const fetchPriceHistory = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/tokens/${tokenId}/price-history?period=${period}`)
      const result = await response.json()

      if (result.success) {
        setData(result.data)
      }
    } catch (error) {
      console.error("[v0] Failed to fetch price history:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchPriceHistory()
  }, [tokenId, period])

  const formatXAxis = (tickItem: string) => {
    const date = new Date(tickItem)
    if (period === "7d") {
      return date.toLocaleDateString(undefined, { weekday: "short" })
    }
    return date.toLocaleDateString(undefined, { month: "short", day: "numeric" })
  }

  const formatTooltip = (value: any, name: string) => {
    if (name === "price") {
      return [
        `$${Number(value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 6 })}`,
        "Price",
      ]
    }
    return [value, name]
  }

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="w-full h-full bg-muted animate-pulse rounded" />
      </div>
    )
  }

  return (
    <div className="space-y-2">
      <div className="flex gap-1">
        {["7d", "30d", "1y"].map((p) => (
          <Button
            key={p}
            variant={period === p ? "default" : "ghost"}
            size="sm"
            onClick={() => setPeriod(p)}
            className="text-xs h-6 px-2"
          >
            {p}
          </Button>
        ))}
      </div>

      <div className="h-24">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <XAxis
              dataKey="timestamp"
              tickFormatter={formatXAxis}
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 10 }}
            />
            <YAxis hide />
            <Tooltip
              formatter={formatTooltip}
              labelFormatter={(label) => new Date(label).toLocaleString()}
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "6px",
                fontSize: "12px",
              }}
            />
            <Line
              type="monotone"
              dataKey="price"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 3, stroke: "hsl(var(--primary))", strokeWidth: 2 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
