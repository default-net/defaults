"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowUpDown, ArrowRight, Clock, DollarSign, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface Chain {
  id: number
  name: string
  symbol: string
  logo: string
  gasToken: string
}

interface Token {
  symbol: string
  name: string
  logo: string
  balance?: number
}

const supportedChains: Chain[] = [
  { id: 1, name: "Ethereum", symbol: "ETH", logo: "/ethereum-logo.png", gasToken: "ETH" },
  { id: 137, name: "Polygon", symbol: "MATIC", logo: "/tokens/logo.png", gasToken: "MATIC" },
  { id: 56, name: "BSC", symbol: "BNB", logo: "/bnb-logo.png", gasToken: "BNB" },
  { id: 43114, name: "Avalanche", symbol: "AVAX", logo: "/avalanche-logo.png", gasToken: "AVAX" },
]

const bridgeableTokens: Token[] = [
  { symbol: "USDT", name: "Tether USD", logo: "/tether-usdt-logo.png", balance: 1250.5 },
  { symbol: "USDC", name: "USD Coin", logo: "/usdc-logo.png", balance: 890.25 },
  { symbol: "ETH", name: "Ethereum", logo: "/ethereum-logo.png", balance: 2.45 },
  { symbol: "BTC", name: "Bitcoin", logo: "/bitcoin-logo.png", balance: 0.15 },
]

export function BridgeInterface() {
  const [fromChain, setFromChain] = useState<Chain>(supportedChains[0])
  const [toChain, setToChain] = useState<Chain>(supportedChains[1])
  const [selectedToken, setSelectedToken] = useState<Token>(bridgeableTokens[0])
  const [amount, setAmount] = useState("")
  const [recipient, setRecipient] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const estimatedFee = 0.005 // ETH
  const estimatedTime = "2-5 minutes"
  const exchangeRate = 1.0001

  const handleSwapChains = () => {
    const temp = fromChain
    setFromChain(toChain)
    setToChain(temp)
  }

  const handleBridge = async () => {
    if (!amount || !recipient) return

    setIsProcessing(true)

    try {
      const response = await fetch("/api/bridge/initiate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fromChainId: fromChain.id,
          toChainId: toChain.id,
          tokenSymbol: selectedToken.symbol,
          amount: Number.parseFloat(amount),
          recipient,
        }),
      })

      const result = await response.json()

      if (result.success) {
        // Handle successful bridge initiation
        console.log("[v0] Bridge transaction initiated:", result.transactionId)
        setAmount("")
        setRecipient("")
      }
    } catch (error) {
      console.error("[v0] Bridge transaction failed:", error)
    } finally {
      setIsProcessing(false)
    }
  }

  const canBridge = amount && recipient && Number.parseFloat(amount) > 0 && !isProcessing

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ArrowUpDown className="h-5 w-5" />
          Bridge Tokens
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Chain Selection */}
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>From Network</Label>
              <Select
                value={fromChain.id.toString()}
                onValueChange={(value) => setFromChain(supportedChains.find((c) => c.id.toString() === value)!)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {supportedChains.map((chain) => (
                    <SelectItem key={chain.id} value={chain.id.toString()}>
                      <div className="flex items-center gap-2">
                        <img src={chain.logo || "/placeholder.svg"} alt={chain.name} className="w-4 h-4 rounded-full" />
                        {chain.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>To Network</Label>
              <div className="flex items-center gap-2">
                <Select
                  value={toChain.id.toString()}
                  onValueChange={(value) => setToChain(supportedChains.find((c) => c.id.toString() === value)!)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedChains
                      .filter((c) => c.id !== fromChain.id)
                      .map((chain) => (
                        <SelectItem key={chain.id} value={chain.id.toString()}>
                          <div className="flex items-center gap-2">
                            <img
                              src={chain.logo || "/placeholder.svg"}
                              alt={chain.name}
                              className="w-4 h-4 rounded-full"
                            />
                            {chain.name}
                          </div>
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
                <Button variant="ghost" size="sm" onClick={handleSwapChains}>
                  <ArrowUpDown className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Token Selection */}
        <div className="space-y-2">
          <Label>Token</Label>
          <Select
            value={selectedToken.symbol}
            onValueChange={(value) => setSelectedToken(bridgeableTokens.find((t) => t.symbol === value)!)}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {bridgeableTokens.map((token) => (
                <SelectItem key={token.symbol} value={token.symbol}>
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-2">
                      <img src={token.logo || "/placeholder.svg"} alt={token.name} className="w-4 h-4 rounded-full" />
                      <span>{token.symbol}</span>
                      <span className="text-muted-foreground text-sm">{token.name}</span>
                    </div>
                    {token.balance && (
                      <Badge variant="outline" className="ml-2">
                        {token.balance.toFixed(4)}
                      </Badge>
                    )}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Amount Input */}
        <div className="space-y-2">
          <Label htmlFor="amount">Amount</Label>
          <div className="relative">
            <Input
              id="amount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="pr-20"
            />
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-sm text-muted-foreground">
              {selectedToken.symbol}
            </div>
          </div>
          {selectedToken.balance && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">
                Available: {selectedToken.balance.toFixed(4)} {selectedToken.symbol}
              </span>
              <Button
                variant="ghost"
                size="sm"
                className="h-auto p-0 text-primary"
                onClick={() => setAmount(selectedToken.balance?.toString() || "")}
              >
                Max
              </Button>
            </div>
          )}
        </div>

        {/* Recipient Address */}
        <div className="space-y-2">
          <Label htmlFor="recipient">Recipient Address</Label>
          <Input id="recipient" placeholder="0x..." value={recipient} onChange={(e) => setRecipient(e.target.value)} />
        </div>

        {/* Bridge Details */}
        {amount && Number.parseFloat(amount) > 0 && (
          <div className="space-y-3 p-4 bg-muted/50 rounded-lg">
            <h3 className="font-medium">Bridge Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">You send:</span>
                <span>
                  {amount} {selectedToken.symbol} on {fromChain.name}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">You receive:</span>
                <span>
                  {(Number.parseFloat(amount) * exchangeRate).toFixed(6)} {selectedToken.symbol} on {toChain.name}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground flex items-center gap-1">
                  <DollarSign className="h-3 w-3" />
                  Bridge fee:
                </span>
                <span>
                  {estimatedFee} {fromChain.gasToken}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Estimated time:
                </span>
                <span>{estimatedTime}</span>
              </div>
            </div>
          </div>
        )}

        {/* Warnings */}
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Make sure the recipient address is correct for the destination network. Bridge transactions cannot be
            reversed.
          </AlertDescription>
        </Alert>

        {/* Bridge Button */}
        <Button onClick={handleBridge} disabled={!canBridge} className="w-full" size="lg">
          {isProcessing ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
              Processing Bridge...
            </>
          ) : (
            <>
              <ArrowRight className="h-4 w-4 mr-2" />
              Bridge Tokens
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  )
}
