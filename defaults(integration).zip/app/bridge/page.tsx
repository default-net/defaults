import { Suspense } from "react"
import { Header } from "@/components/header"
import { BridgeInterface } from "@/components/bridge-interface"
import { BridgeTransactions } from "@/components/bridge-transactions"
import { BridgeStats } from "@/components/bridge-stats"

export default function BridgePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8 space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-balance">Cross-Chain Bridge</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Seamlessly transfer tokens between different blockchain networks with competitive fees and fast processing.
          </p>
        </div>

        <Suspense fallback={<div className="h-32 bg-muted animate-pulse rounded-lg" />}>
          <BridgeStats />
        </Suspense>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <BridgeInterface />
          </div>
          <div>
            <Suspense fallback={<div className="h-96 bg-muted animate-pulse rounded-lg" />}>
              <BridgeTransactions />
            </Suspense>
          </div>
        </div>
      </main>
    </div>
  )
}
