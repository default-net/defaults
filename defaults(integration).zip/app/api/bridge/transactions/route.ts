import { NextResponse } from "next/server"

// Mock bridge transactions data
const mockTransactions = [
  {
    id: "bridge_1703123456789_abc123",
    fromChainId: 1,
    toChainId: 137,
    fromChain: "Ethereum",
    toChain: "Polygon",
    tokenSymbol: "USDT",
    amount: 100.5,
    recipient: "0x742d35Cc6634C0532925a3b8D4C9db96590c6C87",
    status: "completed",
    txHash: "0x1234567890abcdef1234567890abcdef12345678",
    fee: 0.005,
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    completedAt: new Date(Date.now() - 2 * 60 * 60 * 1000 + 5 * 60 * 1000).toISOString(),
  },
  {
    id: "bridge_1703123456790_def456",
    fromChainId: 137,
    toChainId: 56,
    fromChain: "Polygon",
    toChain: "BSC",
    tokenSymbol: "USDC",
    amount: 250.0,
    recipient: "0x8ba1f109551bD432803012645Hac136c22C501e5",
    status: "processing",
    txHash: "0xabcdef1234567890abcdef1234567890abcdef12",
    fee: 0.002,
    createdAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
  },
  {
    id: "bridge_1703123456791_ghi789",
    fromChainId: 56,
    toChainId: 1,
    fromChain: "BSC",
    toChain: "Ethereum",
    tokenSymbol: "ETH",
    amount: 0.5,
    recipient: "0x9f8f72aA9304c8B593d555F12eF6589cC3A579A2",
    status: "pending",
    fee: 0.008,
    createdAt: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
  },
]

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    let filteredTransactions = mockTransactions

    if (status) {
      filteredTransactions = mockTransactions.filter((tx) => tx.status === status)
    }

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 200))

    return NextResponse.json({
      success: true,
      data: filteredTransactions.slice(0, limit),
      total: filteredTransactions.length,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("[v0] Failed to fetch bridge transactions:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch transactions" }, { status: 500 })
  }
}
