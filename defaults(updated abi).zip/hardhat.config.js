require("@nomicfoundation/hardhat-toolbox")
require("dotenv").config()

const useExchangeAPI = process.env.USE_EXCHANGE_API === "true"

const rpcNetworks = {
  ethereum: {
    url: process.env.ETHEREUM_RPC_URL || "https://eth-mainnet.alchemyapi.io/v2/demo",
    accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
    chainId: 1,
  },
  polygon: {
    url: process.env.POLYGON_RPC_URL || "https://polygon-rpc.com",
    accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
    chainId: 137,
  },
  bsc: {
    url: process.env.BSC_RPC_URL || "https://bsc-dataseed1.binance.org",
    accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
    chainId: 56,
  },
  avalanche: {
    url: process.env.AVALANCHE_RPC_URL || "https://api.avax.network/ext/bc/C/rpc",
    accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
    chainId: 43114,
  },
}

module.exports = {
  solidity: {
    version: "0.8.19",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
      viaIR: false,
      evmTarget: "paris",
    },
  },
  networks: useExchangeAPI ? {} : rpcNetworks, // Conditional network config
  etherscan: {
    apiKey: {
      mainnet: process.env.ETHERSCAN_API_KEY,
      polygon: process.env.POLYGONSCAN_API_KEY,
      bsc: process.env.BSCSCAN_API_KEY,
      avalanche: process.env.SNOWTRACE_API_KEY,
    },
  },
}
