"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Bell, Plus, Trash2, TrendingUp, TrendingDown } from "lucide-react"

interface PriceAlert {
  id: string
  tokenSymbol: string
  condition: "above" | "below"
  targetPrice: number
  currentPrice: number
  isActive: boolean
  createdAt: Date
}

export function PriceAlerts() {
  const [alerts, setAlerts] = useState<PriceAlert[]>([
    {
      id: "1",
      tokenSymbol: "BTC",
      condition: "above",
      targetPrice: 50000,
      currentPrice: 45000,
      isActive: true,
      createdAt: new Date(),
    },
    {
      id: "2",
      tokenSymbol: "ETH",
      condition: "below",
      targetPrice: 3000,
      currentPrice: 3200,
      isActive: true,
      createdAt: new Date(),
    },
  ])

  const [newAlert, setNewAlert] = useState({
    tokenSymbol: "",
    condition: "above" as "above" | "below",
    targetPrice: "",
  })

  const addAlert = () => {
    if (!newAlert.tokenSymbol || !newAlert.targetPrice) return

    const alert: PriceAlert = {
      id: Date.now().toString(),
      tokenSymbol: newAlert.tokenSymbol,
      condition: newAlert.condition,
      targetPrice: Number.parseFloat(newAlert.targetPrice),
      currentPrice: 0, // Would be fetched from API
      isActive: true,
      createdAt: new Date(),
    }

    setAlerts([...alerts, alert])
    setNewAlert({ tokenSymbol: "", condition: "above", targetPrice: "" })
  }

  const removeAlert = (id: string) => {
    setAlerts(alerts.filter((alert) => alert.id !== id))
  }

  const toggleAlert = (id: string) => {
    setAlerts(alerts.map((alert) => (alert.id === id ? { ...alert, isActive: !alert.isActive } : alert)))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Price Alerts
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Create New Alert */}
        <div className="space-y-4 p-4 border rounded-lg">
          <h3 className="font-medium">Create New Alert</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="token">Token</Label>
              <Select
                value={newAlert.tokenSymbol}
                onValueChange={(value) => setNewAlert({ ...newAlert, tokenSymbol: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select token" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                  <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                  <SelectItem value="POL">Polygon (POL)</SelectItem>
                  <SelectItem value="USDT">Tether (USDT)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="condition">Condition</Label>
              <Select
                value={newAlert.condition}
                onValueChange={(value: "above" | "below") => setNewAlert({ ...newAlert, condition: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="above">Price goes above</SelectItem>
                  <SelectItem value="below">Price goes below</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="price">Target Price ($)</Label>
              <Input
                id="price"
                type="number"
                placeholder="0.00"
                value={newAlert.targetPrice}
                onChange={(e) => setNewAlert({ ...newAlert, targetPrice: e.target.value })}
              />
            </div>

            <div className="flex items-end">
              <Button onClick={addAlert} className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Add Alert
              </Button>
            </div>
          </div>
        </div>

        {/* Active Alerts */}
        <div className="space-y-3">
          <h3 className="font-medium">Active Alerts ({alerts.filter((a) => a.isActive).length})</h3>
          {alerts.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No price alerts set up yet.</p>
          ) : (
            alerts.map((alert) => (
              <div key={alert.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2 rounded-full ${alert.condition === "above" ? "bg-chart-1/10 text-chart-1" : "bg-destructive/10 text-destructive"}`}
                  >
                    {alert.condition === "above" ? (
                      <TrendingUp className="h-4 w-4" />
                    ) : (
                      <TrendingDown className="h-4 w-4" />
                    )}
                  </div>
                  <div>
                    <div className="font-medium">
                      {alert.tokenSymbol} {alert.condition} ${alert.targetPrice.toLocaleString()}
                    </div>
                    <div className="text-sm text-muted-foreground">Created {alert.createdAt.toLocaleDateString()}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Badge variant={alert.isActive ? "default" : "secondary"}>
                    {alert.isActive ? "Active" : "Paused"}
                  </Badge>
                  <Button variant="ghost" size="sm" onClick={() => toggleAlert(alert.id)}>
                    {alert.isActive ? "Pause" : "Resume"}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => removeAlert(alert.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}
