import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, ArrowUpDown, Star } from "lucide-react"
import Image from "next/image"

// Mock data - in real app this would come from API/database
const mockTokens = [
  {
    id: 1,
    symbol: "BTC",
    name: "Bitcoin",
    price: 45000.0,
    change24h: 2.5,
    marketCap: 880000000000,
    volume24h: 25000000000,
    logo: "/bitcoin-logo.png",
    isFiat: false,
    chainId: 1,
  },
  {
    id: 2,
    symbol: "ETH",
    name: "Ethereum",
    price: 3200.0,
    change24h: 1.8,
    marketCap: 385000000000,
    volume24h: 15000000000,
    logo: "/ethereum-logo.png",
    isFiat: false,
    chainId: 1,
  },
  {
    id: 3,
    symbol: "POL",
    name: "Polygon",
    price: 1.0001,
    change24h: -0.01,
    marketCap: 134000000000,
    volume24h: 847200000,
    logo: "/tokens/logo.png",
    isFiat: false,
    chainId: 137,
  },
  {
    id: 4,
    symbol: "USDT",
    name: "Tether USD",
    price: 1.0,
    change24h: 0.01,
    marketCap: 95000000000,
    volume24h: 45000000000,
    logo: "/tether-usdt-logo.png",
    isFiat: false,
    chainId: 1,
  },
  {
    id: 5,
    symbol: "USD",
    name: "US Dollar",
    price: 1.0,
    change24h: 0,
    marketCap: 0,
    volume24h: 0,
    logo: "/us-dollar-flag.jpg",
    isFiat: true,
    chainId: null,
  },
]

function formatNumber(num: number): string {
  if (num >= 1e12) return `$${(num / 1e12).toFixed(2)}T`
  if (num >= 1e9) return `$${(num / 1e9).toFixed(2)}B`
  if (num >= 1e6) return `$${(num / 1e6).toFixed(2)}M`
  if (num >= 1e3) return `$${(num / 1e3).toFixed(2)}K`
  return `$${num.toFixed(2)}`
}

export function TokenListings() {
  return (
    <Card className="overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b bg-muted/50">
              <th className="text-left p-4 font-medium text-muted-foreground">
                <Button variant="ghost" className="h-auto p-0 font-medium">
                  # <ArrowUpDown className="ml-1 h-3 w-3" />
                </Button>
              </th>
              <th className="text-left p-4 font-medium text-muted-foreground">Token</th>
              <th className="text-right p-4 font-medium text-muted-foreground">
                <Button variant="ghost" className="h-auto p-0 font-medium">
                  Price <ArrowUpDown className="ml-1 h-3 w-3" />
                </Button>
              </th>
              <th className="text-right p-4 font-medium text-muted-foreground">
                <Button variant="ghost" className="h-auto p-0 font-medium">
                  24h Change <ArrowUpDown className="ml-1 h-3 w-3" />
                </Button>
              </th>
              <th className="text-right p-4 font-medium text-muted-foreground">
                <Button variant="ghost" className="h-auto p-0 font-medium">
                  Market Cap <ArrowUpDown className="ml-1 h-3 w-3" />
                </Button>
              </th>
              <th className="text-right p-4 font-medium text-muted-foreground">
                <Button variant="ghost" className="h-auto p-0 font-medium">
                  Volume (24h) <ArrowUpDown className="ml-1 h-3 w-3" />
                </Button>
              </th>
              <th className="text-right p-4 font-medium text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {mockTokens.map((token, index) => (
              <tr key={token.id} className="border-b hover:bg-muted/25 transition-colors">
                <td className="p-4">
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" className="h-auto p-0">
                      <Star className="h-4 w-4" />
                    </Button>
                    <span className="text-muted-foreground">{index + 1}</span>
                  </div>
                </td>
                <td className="p-4">
                  <div className="flex items-center gap-3">
                    <Image
                      src={token.logo || "/placeholder.svg"}
                      alt={`${token.name} logo`}
                      width={32}
                      height={32}
                      className="rounded-full"
                    />
                    <div>
                      <div className="font-medium flex items-center gap-2">
                        {token.name}
                        {token.isFiat && (
                          <Badge variant="outline" className="text-xs">
                            FIAT
                          </Badge>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground">{token.symbol}</div>
                    </div>
                  </div>
                </td>
                <td className="p-4 text-right font-mono">
                  $
                  {token.price.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: token.price < 1 ? 6 : 2,
                  })}
                </td>
                <td className="p-4 text-right">
                  <div
                    className={`flex items-center justify-end gap-1 ${
                      token.change24h > 0
                        ? "text-chart-1"
                        : token.change24h < 0
                          ? "text-destructive"
                          : "text-muted-foreground"
                    }`}
                  >
                    {token.change24h > 0 ? (
                      <TrendingUp className="h-3 w-3" />
                    ) : token.change24h < 0 ? (
                      <TrendingDown className="h-3 w-3" />
                    ) : null}
                    {token.change24h > 0 ? "+" : ""}
                    {token.change24h.toFixed(2)}%
                  </div>
                </td>
                <td className="p-4 text-right font-mono">
                  {token.marketCap > 0 ? formatNumber(token.marketCap) : "—"}
                </td>
                <td className="p-4 text-right font-mono">
                  {token.volume24h > 0 ? formatNumber(token.volume24h) : "—"}
                </td>
                <td className="p-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button size="sm" variant="outline">
                      Trade
                    </Button>
                    <Button size="sm">Bridge</Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  )
}
