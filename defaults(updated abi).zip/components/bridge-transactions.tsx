"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Clock, CheckCircle, XCircle, RefreshCw } from "lucide-react"

interface BridgeTransaction {
  id: string
  fromChain: string
  toChain: string
  tokenSymbol: string
  amount: number
  status: "pending" | "processing" | "completed" | "failed"
  txHash?: string
  createdAt: Date
  completedAt?: Date
}

export function BridgeTransactions() {
  const [transactions, setTransactions] = useState<BridgeTransaction[]>([
    {
      id: "1",
      fromChain: "Ethereum",
      toChain: "Polygon",
      tokenSymbol: "USDT",
      amount: 100.5,
      status: "completed",
      txHash: "0x1234...5678",
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      completedAt: new Date(Date.now() - 2 * 60 * 60 * 1000 + 5 * 60 * 1000),
    },
    {
      id: "2",
      fromChain: "Polygon",
      toChain: "BSC",
      tokenSymbol: "USDC",
      amount: 250.0,
      status: "processing",
      txHash: "0xabcd...efgh",
      createdAt: new Date(Date.now() - 30 * 60 * 1000),
    },
    {
      id: "3",
      fromChain: "BSC",
      toChain: "Ethereum",
      tokenSymbol: "ETH",
      amount: 0.5,
      status: "pending",
      createdAt: new Date(Date.now() - 5 * 60 * 1000),
    },
  ])

  const [loading, setLoading] = useState(false)

  const fetchTransactions = async () => {
    setLoading(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      // In real app, fetch from API
    } catch (error) {
      console.error("[v0] Failed to fetch bridge transactions:", error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-chart-1" />
      case "processing":
        return <RefreshCw className="h-4 w-4 text-primary animate-spin" />
      case "failed":
        return <XCircle className="h-4 w-4 text-destructive" />
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      completed: "default",
      processing: "secondary",
      pending: "outline",
      failed: "destructive",
    } as const

    return (
      <Badge variant={variants[status as keyof typeof variants] || "outline"}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    )
  }

  const formatTimeAgo = (date: Date) => {
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / (1000 * 60))
    const diffHours = Math.floor(diffMins / 60)

    if (diffMins < 60) {
      return `${diffMins}m ago`
    } else if (diffHours < 24) {
      return `${diffHours}h ago`
    } else {
      return date.toLocaleDateString()
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Recent Transactions</CardTitle>
          <Button variant="ghost" size="sm" onClick={fetchTransactions} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {transactions.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">No bridge transactions yet.</p>
        ) : (
          transactions.map((tx) => (
            <div key={tx.id} className="space-y-3 p-4 border rounded-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getStatusIcon(tx.status)}
                  <span className="font-medium">
                    {tx.amount} {tx.tokenSymbol}
                  </span>
                </div>
                {getStatusBadge(tx.status)}
              </div>

              <div className="text-sm text-muted-foreground">
                <div className="flex items-center justify-between">
                  <span>
                    {tx.fromChain} → {tx.toChain}
                  </span>
                  <span>{formatTimeAgo(tx.createdAt)}</span>
                </div>
              </div>

              {tx.txHash && (
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-muted-foreground">{tx.txHash}</span>
                  <Button variant="ghost" size="sm" className="h-auto p-0">
                    <ExternalLink className="h-3 w-3" />
                  </Button>
                </div>
              )}

              {tx.status === "processing" && (
                <div className="text-xs text-muted-foreground">Estimated completion: 2-5 minutes</div>
              )}
            </div>
          ))
        )}
      </CardContent>
    </Card>
  )
}
