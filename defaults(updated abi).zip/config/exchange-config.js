require("dotenv").config()

const exchangeConfig = {
  bitget: {
    apiKey: process.env.BITGET_API_KEY || "bg_2751439d7a867d6830940363af99d46c",
    secretKey: process.env.BITGET_SECRET_KEY || "97340898bf33435b83f444cab4cdbdc8da1c5a2339200d6b888787a91861712a",
    uid: process.env.BITGET_UID || "1333523114",
    baseURL: "https://api.bitget.com",
    testnet: process.env.NODE_ENV !== "production",
  },

  moonpay: {
    apiKey: process.env.MOONPAY_API_KEY || "pk_live_ACUQKNe91OW5aYozHGLuKqxRKOtzXOTU",
    secretKey: process.env.MOONPAY_SECRET_KEY || "sk_live_xnxXF32ipsEbZTNNA89QW9FkaOoSWLgh",
    baseURL: "https://api.moonpay.com",
    sandbox: process.env.NODE_ENV !== "production",
  },

  kraken: {
    apiKey: process.env.KRAKEN_API_KEY || "U/oh3nIW6JyvWUaJkdOrtuxljfbH9NENz01zlv96hQy/Mz7iGu7JnSqk/Mz7iGu7JnSqk",
    secretKey:
      process.env.KRAKEN_SECRET_KEY ||
      "rMG31F0v6J5ciiSh+WfBcg3WNj7H5WZEVq83dCigfznGODaoRMx6dUwPEIf06azjaybEliyEUQ8FTUGbdliXvg==",
    uid: process.env.KRAKEN_UID || "AA62 N84G JULP WMBI",
    baseURL: "https://api.kraken.com",
  },

  okx: {
    apiKey: process.env.OKX_API_KEY || "e2d96d1-ae51-4db1-8b10-4ade7d29ccff",
    secretKey: process.env.OKX_SECRET_KEY || "CF33D0B43066294D5E911334581E4D25",
    passphrase: process.env.OKX_PASSPHRASE || "Meisme@0911",
    uid: process.env.OKX_UID || "581332150872876226",
    baseURL: "https://www.okx.com",
  },

  paxful: {
    appId: process.env.PAXFUL_APP_ID || "BLHBJ9TwpnH0AcD8vdJjN9bgYKCIr3F5tW8WFWjPJnC5Epzi",
    secretKey: process.env.PAXFUL_SECRET_KEY || "pAiWFZyurdLtlpElUpVNkKmLCs3362coXSCuS1nV62R1ASLI",
    uid: process.env.PAXFUL_UID || "ARDENTOCTOPUS33",
    baseURL: "https://paxful.com/api",
  },
}

module.exports = exchangeConfig
