-- Seeding initial token data including the POL token from env file

-- Insert major cryptocurrencies
INSERT INTO tokens (symbol, name, contract_address, chain_id, decimals, is_fiat, logo_url) VALUES
('BTC', 'Bitcoin', NULL, 1, 8, FALSE, '/tokens/btc.png'),
('ETH', 'Ethereum', NULL, 1, 18, FALSE, '/tokens/eth.png'),
('POL', 'Polygon', '0x472dbd86732d57a3a0d9db441c6df91a3e0f298e', 137, 18, FALSE, '/tokens/pol.png'),
('USDT', 'Tether USD', '0xdac17f958d2ee523a2206206994597c13d831ec7', 1, 6, FALSE, '/tokens/usdt.png'),
('USDC', 'USD Coin', '0xa0b86a33e6441e6c7d3e4081f7567f8b8e4c3c2e', 1, 6, FALSE, '/tokens/usdc.png'),
('BNB', 'Binance Coin', NULL, 56, 18, FALSE, '/tokens/bnb.png');

-- Insert major fiat currencies
INSERT INTO tokens (symbol, name, decimals, is_fiat) VALUES
('USD', 'US Dollar', 2, TRUE),
('EUR', 'Euro', 2, TRUE),
('GBP', 'British Pound', 2, TRUE),
('JPY', 'Japanese Yen', 0, TRUE),
('CNY', 'Chinese Yuan', 2, TRUE);

-- Insert initial price data for POL token using env defaults
INSERT INTO token_prices (token_id, price, market_cap, change_24h) 
SELECT id, 1.0001, 134000000000, -0.01 
FROM tokens WHERE symbol = 'POL';

-- Insert sample price data for other major tokens
INSERT INTO token_prices (token_id, price, market_cap, volume_24h, change_24h) VALUES
((SELECT id FROM tokens WHERE symbol = 'BTC'), 45000.00, 880000000000, 25000000000, 2.5),
((SELECT id FROM tokens WHERE symbol = 'ETH'), 3200.00, 385000000000, 15000000000, 1.8),
((SELECT id FROM tokens WHERE symbol = 'USDT'), 1.00, 95000000000, 45000000000, 0.01),
((SELECT id FROM tokens WHERE symbol = 'USDC'), 1.00, 32000000000, 8000000000, -0.02);

-- Create trading pairs
INSERT INTO trading_pairs (base_token_id, quote_token_id, exchange_rate) VALUES
((SELECT id FROM tokens WHERE symbol = 'BTC'), (SELECT id FROM tokens WHERE symbol = 'USD'), 45000.00),
((SELECT id FROM tokens WHERE symbol = 'ETH'), (SELECT id FROM tokens WHERE symbol = 'USD'), 3200.00),
((SELECT id FROM tokens WHERE symbol = 'POL'), (SELECT id FROM tokens WHERE symbol = 'USD'), 1.0001),
((SELECT id FROM tokens WHERE symbol = 'BTC'), (SELECT id FROM tokens WHERE symbol = 'ETH'), 14.06);
