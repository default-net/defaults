const { ethers } = require("ethers")

/**
 * Generate ABI encoded constructor arguments for contract verification
 */

// BridgeToken Constructor Arguments
const bridgeTokenArgs = {
  name: "Bridge Token",
  symbol: "BRIDGE",
  decimals: 18,
  initialSupply: 1000000, // 1M tokens
  owner: "0x742d35Cc6634C0532925a3b8D4C9db96c4b5Da5e", // Replace with actual owner address
}

// CrossChainBridge Constructor Arguments
const crossChainBridgeArgs = {
  owner: "0x742d35Cc6634C0532925a3b8D4C9db96c4b5Da5e", // Replace with actual owner address
}

function generateBridgeTokenABI() {
  console.log("=== BridgeToken Constructor ABI Encoding ===")
  console.log("Constructor Parameters:")
  console.log(`- name: "${bridgeTokenArgs.name}"`)
  console.log(`- symbol: "${bridgeTokenArgs.symbol}"`)
  console.log(`- decimals: ${bridgeTokenArgs.decimals}`)
  console.log(`- initialSupply: ${bridgeTokenArgs.initialSupply}`)
  console.log(`- owner: ${bridgeTokenArgs.owner}`)

  // ABI encode the constructor arguments
  const abiCoder = new ethers.AbiCoder()
  const encoded = abiCoder.encode(
    ["string", "string", "uint8", "uint256", "address"],
    [
      bridgeTokenArgs.name,
      bridgeTokenArgs.symbol,
      bridgeTokenArgs.decimals,
      bridgeTokenArgs.initialSupply,
      bridgeTokenArgs.owner,
    ],
  )

  console.log("\nABI Encoded Constructor Arguments:")
  console.log(encoded)
  console.log("\nFor Etherscan verification, use this encoded data:")
  console.log(encoded.slice(2)) // Remove 0x prefix

  return encoded
}

function generateCrossChainBridgeABI() {
  console.log("\n=== CrossChainBridge Constructor ABI Encoding ===")
  console.log("Constructor Parameters:")
  console.log(`- owner: ${crossChainBridgeArgs.owner}`)

  // ABI encode the constructor arguments
  const abiCoder = new ethers.AbiCoder()
  const encoded = abiCoder.encode(["address"], [crossChainBridgeArgs.owner])

  console.log("\nABI Encoded Constructor Arguments:")
  console.log(encoded)
  console.log("\nFor Etherscan verification, use this encoded data:")
  console.log(encoded.slice(2)) // Remove 0x prefix

  return encoded
}

function generateVerificationData() {
  console.log("🔧 Generating Constructor ABI Encoded Data for Contract Verification\n")

  const bridgeTokenEncoded = generateBridgeTokenABI()
  const crossChainBridgeEncoded = generateCrossChainBridgeABI()

  console.log("\n" + "=".repeat(80))
  console.log("📋 VERIFICATION SUMMARY")
  console.log("=".repeat(80))

  console.log("\n1. BridgeToken Contract:")
  console.log(`   Constructor ABI: ${bridgeTokenEncoded.slice(2)}`)

  console.log("\n2. CrossChainBridge Contract:")
  console.log(`   Constructor ABI: ${crossChainBridgeEncoded.slice(2)}`)

  console.log("\n📝 Instructions for Etherscan Verification:")
  console.log("1. Go to Etherscan contract verification page")
  console.log("2. Select 'Solidity (Single file)' or 'Solidity (Standard JSON)'")
  console.log("3. Enter compiler version: 0.8.19+commit.7dd6d404")
  console.log("4. Set optimization: Yes (200 runs)")
  console.log("5. Paste the ABI encoded constructor arguments above")
  console.log("6. Submit for verification")

  return {
    bridgeToken: bridgeTokenEncoded.slice(2),
    crossChainBridge: crossChainBridgeEncoded.slice(2),
  }
}

// Export for use in other scripts
module.exports = {
  generateVerificationData,
  bridgeTokenArgs,
  crossChainBridgeArgs,
}

// Run if called directly
if (require.main === module) {
  generateVerificationData()
}
