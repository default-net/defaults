const { ethers } = require("hardhat")

async function main() {
  console.log("Deploying Bridge contracts...")

  // Get deployer account
  const [deployer] = await ethers.getSigners()
  console.log("Deploying contracts with account:", deployer.address)
  console.log("Account balance:", (await deployer.getBalance()).toString())

  // Deploy BridgeToken
  const BridgeToken = await ethers.getContractFactory("BridgeToken")
  const bridgeToken = await BridgeToken.deploy(
    "Bridge USDT", // name
    "bUSDT", // symbol
    6, // decimals
    1000000000, // initial supply (1B tokens)
    deployer.address, // owner
  )
  await bridgeToken.deployed()
  console.log("BridgeToken deployed to:", bridgeToken.address)

  // Deploy CrossChainBridge
  const CrossChainBridge = await ethers.getContractFactory("CrossChainBridge")
  const bridge = await CrossChainBridge.deploy(deployer.address)
  await bridge.deployed()
  console.log("CrossChainBridge deployed to:", bridge.address)

  // Add bridge as minter for token
  await bridgeToken.addBridge(bridge.address)
  console.log("Bridge added as token minter")

  // Add token to bridge
  await bridge.addSupportedToken(bridgeToken.address)
  console.log("Token added to bridge")

  // Add deployer as validator
  await bridge.addValidator(deployer.address)
  console.log("Deployer added as validator")

  console.log("\nDeployment Summary:")
  console.log("==================")
  console.log("BridgeToken:", bridgeToken.address)
  console.log("CrossChainBridge:", bridge.address)
  console.log("Network:", await ethers.provider.getNetwork())
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error)
    process.exit(1)
  })
