import { Suspense } from "react"
import { Header } from "@/components/header"
import { TokenListings } from "@/components/token-listings"
import { SearchFilters } from "@/components/search-filters"
import { MarketOverview } from "@/components/market-overview"
import { PriceTracker } from "@/components/price-tracker"
import { PriceAlerts } from "@/components/price-alerts"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8 space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-balance">
            Professional Crypto Trading Platform
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Trade cryptocurrencies and fiat currencies with real-time prices, cross-chain bridges, and
            professional-grade tools.
          </p>
        </div>

        <Suspense fallback={<div className="h-32 bg-muted animate-pulse rounded-lg" />}>
          <MarketOverview />
        </Suspense>

        <Suspense fallback={<div className="h-64 bg-muted animate-pulse rounded-lg" />}>
          <PriceTracker />
        </Suspense>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <SearchFilters />
            <Suspense fallback={<div className="h-96 bg-muted animate-pulse rounded-lg" />}>
              <TokenListings />
            </Suspense>
          </div>

          <div className="space-y-6">
            <PriceAlerts />
          </div>
        </div>
      </main>
    </div>
  )
}
